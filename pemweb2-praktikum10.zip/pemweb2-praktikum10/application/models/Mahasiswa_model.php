<?php
    class Mahasiswa_model extends CI_Model {
   
    private $table = 'mahasiswa';

    public function getAll(){
        //select * from mahasiswa;
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        //select * from mahasiswa where nim=$id;
        $this->db->where('nim', $id);
        $query = $this->db->get($this->table);
        return $query->row();
    }
}

?>